import { combineReducers } from "redux";
import bookReducer from './BookReducer'

const reducers=combineReducers({
bookReducer
})

export default reducers