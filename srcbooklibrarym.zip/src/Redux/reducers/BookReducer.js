const initialState = {
  users: [],
  loginUsers:[],
  loggedInUser: [],
  books: [
    {
      id: 1,
      name: "The power of your subconscious mind",
      quantity: 2,
    },
    {
      id: 2,
      name: "The Monk who sold his ferrari",
      quantity: 2,
    },
    {
      id: 3,
      name: "The Alchemist",
      quantity: 2,
    },
    {
      id: 4,
      name: "The Invisible Man",
      quantity: 2,
    },
    {
      id: 5,
      name: "The Great treasure",
      quantity: 2,
    },
    {
      id: 6,
      name: "The Holy Shit",
      quantity: 2,
    },
  ],
  userBookList: {
   
  },
  

};

const bookReducer = (state = initialState, action) => {
  
  switch (action.type) {
    case "buy":
      // userBookList[`${userId}`] =userBookList[`${userId}`]?.length ? [...userBookList[`${userId}`], action.payload]:[action.payload]
      console.log(state)
      const index = state.books.findIndex((book) => book.id === action.payload);
      const newArray = [...state.books];
      if (newArray[index + 1].quantity < 1) {
        alert('NOT AVAILABLE')
      }
      else {
        newArray[index + 1].quantity = newArray[index + 1].quantity - 1;
      }
      
      const addBook = state.books[index + 1]
      console.log(addBook)
      const bookname = state.books[index + 1].name
      console.log(bookname)

      


      return {
        ...state,
        books: newArray,
        userBookList: [...state.userBookList.user1.books, addBook],
      };
      break;
    case "return":
      const index2 = state.books.findIndex((book) => book.id === action.payload);
      console.log(index2)
      const newArray2 = [...state.books];
      if (newArray2[index2 + 1].quantity >= 2) {
        alert('Not Issued')
      }
      else {
        newArray2[index2 + 1].quantity = newArray2[index2 + 1].quantity + 1;
      }
      return { ...state, books: newArray2 };
      break;
    case "Register":
      return {
        ...state,
        users: [...state.users, action.payload],
      }
      break;
    case "login":
      console.log(action)
      state.userBookList[`${action.payload.username}`] =state.userBookList[`${action.payload.username}`]?.length ? [...state.userBookList[`${action.payload.username}`]]:[]
      console.log( state.userBookList[`${action.payload.username}`])
      return {
        ...state,
        loginUsers:[...state.loginUsers,action.payload],
        loggedInUser: action.payload,
        userBookList: {
          ...state.userBookList,
          [`${action.payload.username}`]: 
            state.userBookList[`${action.payload.username}`]
          
        }

      };
      break;
    case "logout":
      return {
        ...state,
        loggedInUser: [],
        


      };
      break;
    case "BUY1":
      const index1 = state.books.findIndex((book) => book.id === action.payload.data[0].id)
      // console.log(action.payload.data.id)
      console.log(index1)
      

      const newArr = [...state.books];
      newArr[index1].quantity = newArr[index1].quantity - 1;
      return {
        ...state,
        userBookList: {
          ...state.userBookList,
          [`${state.loggedInUser.username}`]: [
            ...state.userBookList[[`${state.loggedInUser.username}`]],
            action.payload.data[0].name
          ]
        }
      }
      break;
    case "BOOKRETURN":
      
      const index3 = state.books.findIndex((book) => book.id === action.payload.data[0].id)
      

      console.log(action.payload.data[0].name)
      function bookFind(book) {
        return book === action.payload.data[0].name

      }
    
      const newBookIndex = state.userBookList[[`${state.loggedInUser.username}`]].findIndex(bookFind)
      console.log(newBookIndex)
      const booksAfter=[...state.userBookList[[`${state.loggedInUser.username}`]]]
       booksAfter.splice(newBookIndex,1)
      const newArr1 = [...state.books];

      newArr1[index3].quantity = newArr1[index3].quantity + 1;
      return {
        ...state,

        userBookList: {
          ...state.userBookList,
          [`${state.loggedInUser.username}`]: 
            booksAfter
          
        }
      };




    default:
      return state;
  }
}
export default bookReducer;