import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import  RouterConfig from './PrivateRoute'
import NavBar from './NavBar';



const App= () => {
   

  return (<>
  {/* <NavBar/> */}
  <RouterConfig/>
  

   
  </>
  )
}

export default App