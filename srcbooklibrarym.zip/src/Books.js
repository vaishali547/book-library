import   React,{ usestate,useEffect } from 'react'
import { Table } from 'react-bootstrap'
import { useSelector,useDispatch } from 'react-redux'
import {
    buyBook,
    returnBook,
    logout,
    buyBook1,
    returnBook1
} from './Redux/Actions'
import { Link } from 'react-router-dom'

const Books= () => {

  useEffect(() => {
    // localStorage.clear()
  },[])

    const books = useSelector((state) => state.bookReducer);
    
    
    const userId1 = books.loggedInUser.username

  const dispatch = useDispatch();

  const abc = (id)=>{
    let newArr = books.books.filter((elem) => elem.id === id)
    // console.log(newArr)
   
    // console.log(books.userBookList[[`${userId1}`]].length)
    function bookFind(book) {
      return book === newArr[0].name

    }
  
    const newBook = books.userBookList[[`${userId1}`]].find(bookFind)
    // console.log(newBook)
    
     if(newBook){
      alert('Already Issued')
    }
    else if(newArr[0].quantity<1){
     alert('Not Available')
    }
    else if(books.userBookList[[`${userId1}`]].length>1){
      alert('Cannot Issue more than 2')
    }
    else{
    dispatch(buyBook1({userId : "user2", data : newArr}))}}
  const efg=(id)=>{
    let newArrr2=books.books.filter((elem)=>elem.id===id)
    function bookFind(book) {
      return book === newArrr2[0].name
    }
    const bookIndex=books.userBookList[[`${userId1}`]].findIndex(bookFind)
    // console.log(bookIndex)
    if(bookIndex!=-1){
      dispatch(returnBook1({userId:'user2',data:newArrr2}))
      
    }
    else{
      alert(' not Bought')
    }
  }
  
  return (
   <>
    <Table striped bordered hover variant="dark" >
    <thead>
      
      <tr>
      <th>S.NO</th>
        <th>Book Name</th>
        <th >Quantity</th>
        <th></th>
        </tr>

    </thead>
    <tbody>
        
         {books.books.map((item,index)=>{
           return(<tr key={index}><td>{item.id}</td>
           <td>{item.name}</td>
           <td>{item.quantity}</td>
           <td>
            <button onClick={() => abc(item.id)}>Buy</button>
            <button onClick={()=>  efg(item.id)} >Return</button>
            
          </td></tr>)
         })}
   </tbody>
  </Table>
  <nav><Link to='/mybooks'>MyBooks</Link></nav>
  <button onClick={()=>{
    dispatch(logout({}))
  }}>logout</button>
  </>
  
  )
}

export default Books;